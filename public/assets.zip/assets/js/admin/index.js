$(document).ready(function() {
    $("#bonus-withdrawal-table").DataTable({
        paging: false,
    });

    $("#upgrades-table").DataTable({
        paging: false,
    });

    $("#leadership-table").DataTable({
        paging: false,
    });
});
